export const onServiceWorkerUpdateReady = () => window.location.reload(true);
